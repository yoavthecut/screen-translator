# Screen Translator

A Python application that allows you to capture and translate text from anywhere on your screen to Hebrew.

## Features

- Screen capture with click and drag
- Instant translation to Hebrew
- Global hotkey support (Ctrl+Alt+T)
- Simple and intuitive interface

## Requirements

- Windows 10 or later
- Python 3.8 or later
- Tesseract OCR

## Installation

1. Install Python 3.8 or later from [python.org](https://www.python.org/downloads/)
2. Install Tesseract OCR from [GitHub](https://github.com/UB-Mannheim/tesseract/wiki)
3. Clone or download this repository
4. Create a virtual environment:
   ```
   python -m venv venv
   .\venv\Scripts\activate
   ```
5. Install required packages:
   ```
   pip install -r requirements.txt
   ```

## Usage

1. Run the application:
   ```
   python test_ocr.py
   ```
2. Press Ctrl+Alt+T to start capturing
3. Click and drag to select text
4. View the Hebrew translation

## Keyboard Shortcuts

- Ctrl+Alt+T: Start capture
- Ctrl+Alt+Q: Quit application
- ESC: Cancel capture

## Troubleshooting

If you encounter any issues:
1. Make sure Tesseract OCR is properly installed
2. Verify Python and all dependencies are installed
3. Check that the virtual environment is activated

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Project Structure
```
translateapp/
├── main.py              # Application entry point
├── requirements.txt     # Project dependencies
├── src/
│   ├── ocr.py          # OCR functionality
│   ├── translator.py    # Translation service
│   ├── ui/
│   │   ├── tray.py     # System tray implementation
│   │   ├── popup.py    # Translation popup window
│   │   └── settings.py # Settings window
│   └── utils/
│       ├── config.py   # Configuration management
│       └── storage.py  # Word list storage
└── data/
    └── words.json      # Saved words database
``` 