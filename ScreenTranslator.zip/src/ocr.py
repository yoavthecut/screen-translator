import sys
import pytesseract
from PIL import Image, ImageGrab, ImageEnhance
import numpy as np
from PyQt6.QtWidgets import QApplication, QRubberBand, QWidget
from PyQt6.QtCore import Qt, QRect, QPoint
from PyQt6.QtGui import QPainter, QColor, QPen
import time

class ScreenCapturer(QWidget):
    def __init__(self):
        super().__init__()
        # Set up the window to be fullscreen and transparent
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setCursor(Qt.CursorShape.CrossCursor)  # Set crosshair cursor
        
        # Get screen geometry and set window size
        self.screen = QApplication.primaryScreen()
        self.screen_geometry = self.screen.geometry()
        self.setGeometry(self.screen_geometry)
        
        # Initialize rubber band with a more visible style
        self.rubber_band = QRubberBand(QRubberBand.Shape.Rectangle, self)
        self.rubber_band.setStyleSheet("""
            QRubberBand {
                border: 2px solid #00ff00;
                background: rgba(0, 255, 0, 0.1);
            }
        """)
        
        self.origin = QPoint()
        self.is_selecting = False
        self.captured_text = None
        
        # Show instructions
        print("Click and drag to select a region. Press ESC or right-click to cancel.")

    def paintEvent(self, event):
        """Paint the semi-transparent overlay"""
        painter = QPainter(self)
        # Draw semi-transparent background
        painter.fillRect(self.rect(), QColor(0, 0, 0, 100))
        
        # Draw instructions
        painter.setPen(QPen(QColor(255, 255, 255), 2))  # White, 2px thick
        painter.setFont(self.font())
        text = "Click and drag to select text (ESC to cancel)"
        text_rect = painter.fontMetrics().boundingRect(text)
        x = (self.width() - text_rect.width()) // 2
        y = (self.height() - text_rect.height()) // 2
        painter.drawText(x, y, text)

    def preprocess_image(self, image):
        """Preprocess the image to improve OCR accuracy"""
        # Convert to RGB if needed
        if image.mode != 'RGB':
            image = image.convert('RGB')
        
        # Enhance contrast
        enhancer = ImageEnhance.Contrast(image)
        image = enhancer.enhance(2.0)
        
        # Enhance sharpness
        enhancer = ImageEnhance.Sharpness(image)
        image = enhancer.enhance(2.0)
        
        return image

    def capture_and_process(self, rect):
        """Capture the selected region and process it with OCR"""
        try:
            # Add a small delay to ensure the rubber band is hidden
            self.rubber_band.hide()
            QApplication.processEvents()
            time.sleep(0.1)  # Small delay to ensure screen updates
            
            # Get the screen coordinates
            screen_pos = self.mapToGlobal(QPoint(0, 0))
            x = screen_pos.x() + rect.x()
            y = screen_pos.y() + rect.y()
            w = rect.width()
            h = rect.height()
            
            print(f"Capturing region: x={x}, y={y}, w={w}, h={h}")
            
            # Capture the screen region
            screenshot = ImageGrab.grab(bbox=(x, y, x+w, y+h))
            
            # Preprocess the image
            screenshot = self.preprocess_image(screenshot)
            
            # Save the preprocessed screenshot for debugging
            screenshot.save('debug_capture.png')
            print("Debug image saved as 'debug_capture.png'")
            
            # Process with OCR with additional options
            text = pytesseract.image_to_string(
                screenshot,
                config='--psm 6 --oem 3'  # Assume uniform text block
            )
            text = text.strip()
            
            if not text:
                print("No text detected in the selected region.")
                print("Try selecting a larger area or text with better contrast.")
                return None
            
            print(f"Captured text: {text}")
            return text
            
        except Exception as e:
            print(f"OCR Error: {e}")
            return None

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.origin = event.pos()
            self.rubber_band.setGeometry(QRect(self.origin, QPoint()))
            self.rubber_band.show()
            self.is_selecting = True
        elif event.button() == Qt.MouseButton.RightButton:
            self.hide()
            self.captured_text = None
            QApplication.quit()

    def mouseMoveEvent(self, event):
        if self.is_selecting:
            selection = QRect(self.origin, event.pos()).normalized()
            self.rubber_band.setGeometry(selection)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and self.is_selecting:
            self.is_selecting = False
            selection = self.rubber_band.geometry()
            
            # Only process if selection is large enough
            if selection.width() > 20 and selection.height() > 10:
                self.captured_text = self.capture_and_process(selection)
            else:
                print("Selection too small. Please select a larger area.")
            
            self.hide()
            QApplication.quit()

    def keyPressEvent(self, event):
        """Handle key press events"""
        if event.key() == Qt.Key.Key_Escape:
            self.hide()
            self.captured_text = None
            QApplication.quit()

class OCREngine:
    def __init__(self):
        # Configure Tesseract path
        if sys.platform == 'win32':
            pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    
    def capture_screen_region(self):
        """Start the screen capture process"""
        app = QApplication.instance() or QApplication(sys.argv)
        capturer = ScreenCapturer()
        capturer.showFullScreen()  # Use showFullScreen instead of show
        app.exec()
        return capturer.captured_text
    
    def process_image(self, image):
        """Process an image with OCR"""
        try:
            text = pytesseract.image_to_string(image)
            return text.strip()
        except Exception as e:
            print(f"OCR Error: {e}")
            return None 