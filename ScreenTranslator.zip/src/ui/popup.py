from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont, QCursor

class TranslationPopup(QWidget):
    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.timer = QTimer()
        self.timer.timeout.connect(self.hide)
    
    def setup_ui(self):
        """Set up the popup UI"""
        # Set window flags for a frameless window that stays on top
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        
        # Set up layout
        layout = QVBoxLayout()
        layout.setContentsMargins(10, 10, 10, 10)
        
        # Create labels
        self.original_label = QLabel()
        self.original_label.setFont(QFont('Arial', 10))
        self.original_label.setWordWrap(True)
        self.original_label.setStyleSheet('color: #cccccc;')
        
        self.translation_label = QLabel()
        self.translation_label.setFont(QFont('Arial', 12, QFont.Weight.Bold))
        self.translation_label.setWordWrap(True)
        self.translation_label.setStyleSheet('color: white;')
        
        # Add labels to layout
        layout.addWidget(self.original_label)
        layout.addWidget(self.translation_label)
        
        # Set layout
        self.setLayout(layout)
        
        # Set style
        self.setStyleSheet("""
            QWidget {
                background-color: #2b2b2b;
                border-radius: 5px;
                border: 1px solid #3f3f3f;
            }
        """)
    
    def show_translation(self, original_text, translated_text, duration=3000):
        """Show the translation popup"""
        # Set text
        self.original_label.setText(original_text)
        self.translation_label.setText(translated_text)
        
        # Adjust size
        self.adjustSize()
        
        # Position near the cursor
        cursor_pos = QCursor.pos()
        self.move(cursor_pos.x() + 20, cursor_pos.y() + 20)
        
        # Show popup
        self.show()
        
        # Start timer to hide popup
        self.timer.start(duration)
    
    def mousePressEvent(self, event):
        """Handle mouse press to hide popup"""
        self.hide()
        self.timer.stop() 