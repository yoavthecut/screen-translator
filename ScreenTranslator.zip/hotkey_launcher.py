import keyboard
import subprocess
import sys
import os

def run_translator():
    # Get the directory of this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    # Run the translator script
    subprocess.Popen([sys.executable, os.path.join(script_dir, 'test_ocr.py')])

def main():
    print("Translator hotkey launcher is running...")
    print("Press Ctrl+Alt+T to capture and translate text")
    print("Press Ctrl+Alt+Q to quit")
    
    # Register the hotkey
    keyboard.add_hotkey('ctrl+alt+t', run_translator)
    keyboard.add_hotkey('ctrl+alt+q', lambda: sys.exit())
    
    # Keep the script running
    keyboard.wait()

if __name__ == "__main__":
    main() 