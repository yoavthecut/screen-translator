from PyQt6.QtWidgets import QApplication
import sys
from src.ocr import OCREngine
from src.ui.popup import TranslationPopup
from deep_translator import GoogleTranslator

def main():
    # Initialize components
    app = QApplication(sys.argv)
    ocr = OCREngine()
    popup = TranslationPopup()
    translator = GoogleTranslator(source='auto', target='iw')
    
    print("Select a region on your screen to capture text...")
    
    # Start screen capture
    text = ocr.capture_screen_region()
    
    if text:
        print("\nCaptured text:", text)
        
        # Translate the text
        try:
            translation = translator.translate(text)
            print("Translation:", translation)
            
            # Show the result
            popup.show_translation(text, translation)
            
            # Keep the application running
            return app.exec()
        except Exception as e:
            print("Translation error:", e)
            return 1
    else:
        print("No text was captured.")
        return 1

if __name__ == "__main__":
    sys.exit(main()) 